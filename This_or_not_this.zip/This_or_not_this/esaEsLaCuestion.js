
//Esa es la cuestión!!!


//Instanciamos nuestras canchas
var Futbol = new Cancha("futbol","led",5,5,5);
var Voley = new Cancha("voley","alogeno",3,3,3);

Futbol.preparaCancha();
Voley.preparaCancha();